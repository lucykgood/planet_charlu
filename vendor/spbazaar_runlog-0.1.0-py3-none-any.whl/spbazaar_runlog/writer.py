"""Dependency-free structured event writer and best-effort HTML refresh."""
from __future__ import annotations
import json
import logging
import time
import webbrowser
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO, Optional

SCHEMA_VERSION = 1
logger = logging.getLogger(__name__)

def _open_in_browser(path: Path) -> None:
    """Best-effort: a headless environment (a Docker container with no
    display, CI) has no browser to open, and that must never take down the
    run it's reporting on.
    """
    try:
        webbrowser.open(path.resolve().as_uri())
    except Exception:
        logger.exception("failed to open %s in a browser", path)


@dataclass(frozen=True)
class RunLog:
    """Append-only, immediately flushed schema-v1 JSON Lines writer.

    Use ``RunLog.open(path)`` as a context manager and ``write(event, tick,
    fields)`` with JSON-serializable fields. Client adapters translate their
    own domain objects to the Bazaar event schema.
    """

    path: Path
    _file: IO[str]
    _seen_transactions: set
    open_browser: bool = False
    _browser_opened: list = field(default_factory=list)

    @classmethod
    def open(cls, path: str | Path, *, open_browser: bool = False) -> "RunLog":
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        handle = open(path, "a", encoding="utf-8")
        return cls(path=path, _file=handle, _seen_transactions=set(), open_browser=open_browser)

    def __enter__(self) -> "RunLog":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def close(self) -> None:
        self._file.close()

    def refresh_html(self) -> Optional[Path]:
        """Regenerate this run's HTML summary right now, so a page already
        open in a browser can pick up progress on its next reload instead of
        only ever showing the state as of when the run finished. Returns the
        path written, or ``None`` if rendering failed.

        Imported locally (not at module level) so a summary-rendering bug can
        never become an import-time failure for every caller of this module;
        and best-effort for the same reason a rendering hiccup must not be
        allowed to interrupt the run it's reporting on.

        The very first successful write of a run also opens the page in a
        browser, when ``open_browser`` was requested -- once only per
        ``RunLog``, tracked by ``_browser_opened``, so a live-updating page
        already open doesn't get a fresh tab shoved at the user on every tick.
        """
        try:
            from spbazaar_runlog.run_summary import write_summary
            out_path = write_summary(self.path)
        except Exception:
            logger.exception("failed to refresh HTML summary from %s", self.path)
            return None
        if self.open_browser and not self._browser_opened:
            self._browser_opened.append(True)
            _open_in_browser(out_path)
        return out_path

    def write(self, event: str, tick: Optional[int], fields: dict) -> None:
        reserved = {"schema_version", "event", "wall_time", "tick"}
        if reserved.intersection(fields):
            raise ValueError("fields must not override event envelope keys")
        record = {
            "schema_version": SCHEMA_VERSION,
            "event": event,
            "wall_time": time.time(),
            "tick": tick,
            **fields,
        }
        self._file.write(json.dumps(record, sort_keys=True))
        self._file.write("\n")
        self._file.flush()

